from accounts.models import usercrop, userloc
from django.contrib import admin

# Register your models here.
admin.site.register(userloc)
admin.site.register(usercrop)