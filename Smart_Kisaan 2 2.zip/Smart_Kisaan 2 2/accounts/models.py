from django.db import models

# Create your models here.
class userloc(models.Model):
    user = models.TextField()
    state = models.TextField()
    city = models.TextField()
    created_on = models.DateTimeField(auto_now=True)

class usercrop(models.Model):
    user = models.TextField()
    crop = models.EmailField()
    created_on = models.DateTimeField(auto_now=True)