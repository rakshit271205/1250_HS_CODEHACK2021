from accounts.models import usercrop, userloc
from django.shortcuts import redirect, render
from django.contrib.auth.models import User, auth
from django.contrib import messages
from django.contrib.auth.decorators import login_required
import requests, json

key = "a9ed141cb1d02b9ad3d94d6107594c37"
url = "https://api.openweathermap.org/data/2.5/weather?appid="
h_state1 = "hidden"
h_state2 = "hidden"


weather_text_rainy = """
it is rainy, wate your crops less
"""
weather_text_sunny = """
it is rainy, rainy text will come here
"""
weather_text_cloudy = """
it is rainy, rainy text will come here
"""
weather_info = "Choose a city"
ico = "default.png"


# Create your views here.

@login_required
def home(request):
    current_user = request.user
    uii = current_user.id
    global weather_info
    global ico
    try:
        ussss = userloc.objects.get(user = uii)
        if (ussss.state == "") or (ussss.city == ""):
            c_sel_state = ""
            crop_sel_state = ""
        else:
            c_sel_state = h_state1
            crop_sel_state = h_state2
            city = ussss.city
            complete_url = url + key + "&q=" + city
            response = requests.get(complete_url)
            x = response.json()
            if x["cod"] != "404":
                z = x["weather"]
                ico = z[0]["icon"]
                ico = "templates/images/" + ico + ".png"
                weather_description = z[0]["description"] #important line
                weather_info = weather_description
            else:
                weather_info = "Unable to locate city"
    except:
        c_sel_state = ""
        crop_sel_state = ""
    context = {'c_sel_state': c_sel_state, 'crop_sel_state' : crop_sel_state, 'weather_info' : weather_info, 'ico' : ico}
    return render(request, 'home.html', context)

def signup(request):
    context = {}
    if request.method == "POST":
        first_name = ""
        last_name = ""
        user_name = ""
        email_id = ""
        password1 = ""
        password2 = ""
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        user_name = request.POST['user_name']
        email_id = request.POST['email_id']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        if (password1 == password2):
            if User.objects.filter(username=user_name).exists():
                messages.info(request, "Username Taken")
                return render(request, 'signup.html', context)
            elif User.objects.filter(email=email_id).exists():
                messages.info(request, "Email already taken")
                return render(request, 'signup.html', context)
            elif ((first_name == "") or (last_name == "") or (user_name == "") or (email_id == "") or (password1 == "") or (password2 == "")):
                messages.info(request, "Some required fields are blank")
                return render(request, 'signup.html', context)
            else:
                user = User.objects.create_user(username=user_name, password=password1, email=email_id,first_name=first_name,last_name=last_name)
                user.save()
                return redirect('login')
        else:
         messages.info(request, "password not valid")
         return render(request, 'signup.html', context)
    else:
        return render(request, 'signup.html', context)

def login(request):
    context = {}
    if request.method == "POST":
        user_name = request.POST['user_name']
        password = request.POST['password1']

        user = auth.authenticate(username = user_name, password = password)
        if user is not None:
            auth.login(request, user)
            return redirect('/')
        else:
            messages.info(request, 'Invalid Credentials')
            return redirect('login')
    else:
        return render(request, 'login.html', context)


def logout(request):
    auth.logout(request)
    return redirect('/')

@login_required
def countryselector(request):
    global h_state1
    if (h_state1 == "hidden"):
        h_state1 = ""
    else:
        h_state1 = "hidden"
    return redirect('/')

@login_required
def cropselector(request):
    global h_state2
    if (h_state2 == "hidden"):
        h_state2 = ""
    else:
        h_state2 = "hidden"
    return redirect('/')

@login_required
def countery_select(request, state, city):
    current_user = request.user
    uii = current_user.id
    ussss = userloc(user = uii, state = state, city = city)
    ussss.save()
    return redirect('/')

@login_required
def crop_select(request, crop):
    current_user = request.user
    uii = current_user.id
    ussss = usercrop(user = uii, crop = crop)
    ussss.save()
    return redirect('/')